// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
import { initializeAuth, getReactNativePersistence } from 'firebase/auth';
import ReactNativeAsyncStorage from '@react-native-async-storage/async-storage';

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyA07Z-wq6XGV45fYCPdiaaAzBadqoX7rCI",
  authDomain: "adv-login-6ae41.firebaseapp.com",
  projectId: "adv-login-6ae41",
  storageBucket: "adv-login-6ae41.appspot.com",
  messagingSenderId: "1098607318509",
  appId: "1:1098607318509:web:dc2e37acd2df41de8903e4"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(ReactNativeAsyncStorage)
});