// LoginScreen.js
import React, { useState } from 'react';
import { View, Text, Image, TextInput, TouchableOpacity } from 'react-native';
import { CheckBox } from 'react-native-elements';

const LoginScreen = ({ navigation }) => {
  const [rememberMe, setRememberMe] = useState(false);

  const handleRememberMe = () => {
    setRememberMe(!rememberMe);
    console.log('Remember me pressed');
  };

  const handleSignIn = () => {
    // You can perform any login logic here
    // For now, let's just navigate to the Home screen
    navigation.navigate('Home');
  };

  return (
    <View style={{ flex: 1 }}>
     
      <Image
        style={{ width: 444, height: 732 }}
        source={{ uri: 'https://cdn.discordapp.com/attachments/1008765008366288897/1177873284117835837/nfbg.jpg?ex=657416fa&is=6561a1fa&hm=1d414c15835d4987e7a26310e5fe6efe71d17b891b8e19f7e694ee761dc44da0&' }}
      />
      <View style={{ position: 'absolute', width: 327, height: 406, backgroundColor: '#BE000000' }} />
      <Image
        style={{ width: 232, height: 85, position: 'absolute', top: '12.3%', alignSelf: 'center' }}
        source={{ uri: 'https://media.discordapp.net/attachments/1008765008366288897/1177874448515350528/Logonetflix.png?ex=65741810&is=6561a310&hm=b16b0b67c8a0eb6006c43aa3da2c4aa48a85170803467fbe5f2efedc46a5b7a8&' }}
      />
      <View style={{ position: 'absolute', width: 285, height: 45, backgroundColor: '#992B2A2A', top: '44.1%' }} />
      <View style={{ position: 'absolute', width: 285, height: 45, backgroundColor: '#992B2A2A', top: '55.2%', alignSelf: 'center' }} />

      <TextInput
        style={{ width: 278, height: 40, color: '#80FFFFFF', fontSize: 14, position: 'absolute', top: '44.2%', alignSelf: 'center' }}
        placeholder="Email or phone number"
        placeholderTextColor="#80FFFFFF"
        keyboardType="email-address"
      />
      <TextInput
        style={{ width: 278, height: 40, color: '#80FFFFFF', fontSize: 14, position: 'absolute', top: '55.5%', alignSelf: 'center' }}
        placeholder="Password"
        placeholderTextColor="#80FFFFFF"
        secureTextEntry
      />

      <View style={{ flexDirection: 'row', alignItems: 'center', position: 'absolute', top: '62.1%', alignSelf: 'center' }}>
        <CheckBox
          checked={rememberMe}
          onPress={handleRememberMe}
          containerStyle={{ marginRight: 10 }}
        />
        <Text style={{ color: '#80FFFFFF', fontSize: 14 }}>Remember me</Text>
      </View>
      <TouchableOpacity
        onPress={handleSignIn}
        style={{ width: 132, height: 47, position: 'absolute', top: '70.4%', alignSelf: 'center', backgroundColor: '#E40914', justifyContent: 'center', alignItems: 'center' }}
      >
        <Text style={{ color: 'white', fontSize: 16 }}>SIGN IN</Text>
      </TouchableOpacity>
    </View>
  );
};

export default LoginScreen;
